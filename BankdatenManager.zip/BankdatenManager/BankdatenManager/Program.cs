﻿
namespace BankdatenManager
{
    public class BankManager
    {

        public BankManager(string cardNum, int pin, string firstName, string lastName, int balance)
        {

        }

        public static void Main(string[] args)
        {
            //Show the List of Options/Functions

            void printOptions()
            {
                Console.WriteLine("\nWelcome to the Bank Manager! Please choose from one of the following options: ");
                Console.WriteLine("1. Show the List of Customers ");
                Console.WriteLine("2. Add New Customers ");
                Console.WriteLine("3. Remove Existed Customers ");
                Console.WriteLine("4. Find Existing Customers ");
                Console.WriteLine("5. Login to Show Balance ");
                Console.WriteLine("6. Exit the Program ");

            }

            //List of Customers

            PersonManager manager = new PersonManager();

            manager.AddPerson(new People() { personId = 0609, personFirstName = "Linh", personLastName = "Phan", personEmail = "linh.phan@telekom.de" });
            manager.AddPerson(new People() { personId = 0703, personFirstName = "Sebastian", personLastName = "Feige", personEmail = "sebastian.feige@bdo.de" });
            manager.AddPerson(new People() { personId = 1010, personFirstName = "Random", personLastName = "User", personEmail = "random.user@world.de" });


            //The 1st Part: Check, Add, Remove & Find Customers

            int option = 0;

            do
            {
                printOptions();
                try { option = int.Parse(Console.ReadLine()); }
                catch { }
                if (option == 1) { ShowList(manager); } /*Show List of Customers*/
                else if (option == 2) { manager.AddPerson(AddPerson()); ShowList(manager); } /*Add New Customer*/
                else if (option == 3) { RemovePerson(manager); } /*Remove Customer*/
                else if (option == 4) { FindPerson(manager); } /*Find Customer*/
                else if (option == 5) { cardHolder.CardHolder(); } /*Login*/
                else if (option == 6) { break; } /*Exits*/
                else { Console.WriteLine("*** Please Enter a valid Input! ***"); }

            }
            while (option != 6);
            Console.WriteLine("\nThank you for using our service. Have a nice day!");
        }

        // Show the List of Customers
        private static void ShowList(PersonManager manager)
        {
            foreach (People aPerson in manager.GetId())
            {
                Console.WriteLine(aPerson);
            }
        }

        //Add New Customer

        private static People AddPerson()
        {
            People NewPerson = new People();

            Console.WriteLine("\n - Add New Customer's ID: ");
            NewPerson.personId = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\n - Add New Customer's First Name:");
            NewPerson.personFirstName = Console.ReadLine();

            Console.WriteLine("\n - Add New Customer's Last Name:");
            NewPerson.personLastName = Console.ReadLine();

            Console.WriteLine("\n - Add New Customer's E-Mail Address:");
            NewPerson.personEmail = Console.ReadLine();

            Console.WriteLine("New Customer added succesfully! Please press Enter to continue.");
            Console.ReadLine();

            return NewPerson;
        }

        //Remove a Customer

        private static void RemovePerson(PersonManager personManager)
        {
            Console.WriteLine("Are you sure you want to remove a Customer out of the Database? (yes or no) ");
            string delete = Console.ReadLine();

            if (delete == "yes")
            {
                Console.WriteLine("\nTo remove a Customer please enter a valid Customer's ID: ");
                int deletePerson = Convert.ToInt32(Console.ReadLine());

                List<People> persons = personManager.FindPersons(deletePerson);

                foreach (People personen in persons)
                {
                    personManager.RemovePerson(personen);

                    Console.WriteLine($"\nCustomer Information \n {personen.ToString()} \nhas been deleted successfully!");
                }
            }
            else
            {
                Console.WriteLine("Please enter a valid Input!");
            }
        }

        //Find a Customer

        private static void FindPerson(PersonManager personManager)
        {
            Console.WriteLine("To find a Customer please enter a valid Customer's ID: ");
            int findUser = Convert.ToInt32(Console.ReadLine());

            List<People> people = personManager.FindPersons(findUser);

            foreach (People person in people)
            {
                Console.WriteLine(person.ToString());
            }
        }



    }
}