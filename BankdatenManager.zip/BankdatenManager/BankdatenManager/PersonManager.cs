﻿namespace BankdatenManager
{
    public class PersonManager
    {
        public List<People> people = new List<People>();


        public void AddPerson(People person) { this.people.Add(person); }

        public List<People> GetId() { return this.people; }

        public bool RemovePerson(People person) { return this.people.Remove(person); }


        public bool RemovePersonById(int personId)
        {
            foreach (People aPerson in people)
            {
                if (aPerson.personId == personId)
                {
                    return RemovePerson(aPerson);
                }
            }
            return false;
        }

        public List<People> FindPersons(int personId)
        {
            List<People> findPerson = new List<People>();

            foreach (People person in people)
            {
                if (person.personId == personId)
                {
                    findPerson.Add(person);
                }
            }

            if (findPerson.Count == 0)
            {
                Console.WriteLine("Invalid ID! Please try again");
            }

            return findPerson;
        }


    }
}
