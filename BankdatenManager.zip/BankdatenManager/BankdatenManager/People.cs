﻿namespace BankdatenManager
{
    public class People
    {
        public int personId { get; set; }
        public string personLastName { get; set; }
        public string personFirstName { get; set; }
        public string personEmail { get; set; }

        public override string ToString()
        {
            return "\n[x] Customer's ID: " + personId + " --- Name: " + personFirstName + " --- Last Name: " + personLastName + " --- E-Mail: " + personEmail + "\n";
        }

    }
}
